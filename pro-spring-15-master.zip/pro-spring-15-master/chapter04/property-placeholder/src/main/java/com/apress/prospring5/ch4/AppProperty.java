package com.apress.prospring5.ch4;

import lombok.Getter;
import lombok.Setter;

public class AppProperty {
    @Getter @Setter private String applicationHome;
    @Getter @Setter private String userHome;
}
