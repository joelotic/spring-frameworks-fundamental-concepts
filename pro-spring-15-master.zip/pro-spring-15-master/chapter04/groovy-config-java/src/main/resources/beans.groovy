package com.apress.prospring5.ch4

import com.apress.prospring5.ch3.xml.Singer

beans {
    singer(Singer, name: 'John Mayer', age: 39)
}
