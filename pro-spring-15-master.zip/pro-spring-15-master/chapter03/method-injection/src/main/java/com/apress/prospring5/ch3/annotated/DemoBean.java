package com.apress.prospring5.ch3.annotated;

public interface DemoBean {
    Singer getMySinger();
    void doSomething();
}
