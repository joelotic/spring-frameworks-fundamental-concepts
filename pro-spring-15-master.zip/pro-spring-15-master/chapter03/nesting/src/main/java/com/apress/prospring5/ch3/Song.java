package com.apress.prospring5.ch3;

import lombok.Getter;
import lombok.Setter;

public class Song {
    @Getter
    @Setter
    private String title;
}
