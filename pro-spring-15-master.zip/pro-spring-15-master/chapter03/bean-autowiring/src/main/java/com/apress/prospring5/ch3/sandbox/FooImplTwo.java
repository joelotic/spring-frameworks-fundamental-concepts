package com.apress.prospring5.ch3.sandbox;

import org.springframework.stereotype.Component;

/**
 * Created by iuliana.cosmina on 2/23/17.
 */
@Component
public class FooImplTwo implements Foo{

}
