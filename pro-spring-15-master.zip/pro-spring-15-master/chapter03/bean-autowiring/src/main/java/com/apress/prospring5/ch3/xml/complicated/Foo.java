package com.apress.prospring5.ch3.xml.complicated;

/**
 * Created by iuliana.cosmina on 2/24/17.
 */
public interface Foo {

}
