package com.apress.prospring5.ch5;

public class SmokingException extends Exception {

    public SmokingException(String message) {
        super(message);
    }
}
